package com.example.jwt.customresponse;

import java.util.Date;

import com.example.jwt.models.AdminDetails;

public class CustomResponseForAdminLogin {
	
	private Date timestamp;
	private String message;
	private String status;
	private AdminDetails adminDetails;
	
	
	public CustomResponseForAdminLogin() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CustomResponseForAdminLogin(Date timestamp, String message, String status, AdminDetails adminDetails) {
		super();
		this.timestamp = timestamp;
		this.message = message;
		this.status = status;
		this.adminDetails = adminDetails;
	}
	public Date getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public AdminDetails getAdminDetails() {
		return adminDetails;
	}
	public void setAdminDetails(AdminDetails adminDetails) {
		this.adminDetails = adminDetails;
	}
	
	
	

}
