package com.example.jwt.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.jwt.models.AdminDetails;
import com.example.jwt.repository.AdminRepository;
import com.example.jwt.security.AdminDetailsImpl;

@Service
public class AdminDetailsServiceImpl implements UserDetailsService{
	
	@Autowired
	AdminRepository adminRepository;

	@Override
	public UserDetails loadUserByUsername(String emailId) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		AdminDetails adminDetails = adminRepository.fetchAdminByEmail(emailId);
		
		if(adminDetails == null) {
			throw new UsernameNotFoundException("Admin Not Found With email");
		}
		
		return AdminDetailsImpl.build(adminDetails);
	}

}
