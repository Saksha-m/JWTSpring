package com.example.jwt.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.jwt.customresponse.CustomResponseForAdminLogin;
import com.example.jwt.customresponse.CustomResponseForNoUser;
import com.example.jwt.customresponse.CustomeResponseForLogin;
import com.example.jwt.models.AdminDetails;
import com.example.jwt.security.AdminDetailsImpl;
import com.example.jwt.security.JwtUtils;
import com.example.jwt.service.AdminService;

@RestController
public class AdminController {
	
	
	@Autowired
	AdminService adminService;
	
	@Autowired
	PasswordEncoder encoder;
	
	@Autowired
	AuthenticationManager authenticationManager;
	
	@Autowired
	JwtUtils jwtUtils;
	
	
	@GetMapping("/hello")
	public String hello() {
		
		return "It will Say Hello";		
	}
	
	@PostMapping("/createAdmin")
	public ResponseEntity<Object> createAdmin(@RequestBody AdminDetails adminDetails){
		
		AdminDetails fetchAdmin = adminService.fetchAdminByEmail(adminDetails.getEmailId());
		
		if(fetchAdmin == null) {
			AdminDetails admin = adminService.createAdmin(adminDetails);
			
			CustomResponseForAdminLogin response = new CustomResponseForAdminLogin(new Date(),"Admin Created Succfully","200",admin);
		
			return new ResponseEntity<Object>(response,HttpStatus.OK);
		}else {
			
			CustomResponseForNoUser response = new CustomResponseForNoUser(new Date(),"Admin Email Already Exists..!!","409");
			
			return new ResponseEntity<Object>(response,HttpStatus.OK);
		}
		
	}
	
	
	@PostMapping("/adminLogin")
	public ResponseEntity<Object> adminLogin(@RequestBody AdminDetails adminDetails){
		
		AdminDetails fetchAdmin = adminService.fetchAdminByEmail(adminDetails.getEmailId());
		if(fetchAdmin != null) {
			
			if(encoder.matches(adminDetails.getAdminPassword(),fetchAdmin.getAdminPassword()) == true) {
				
				Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(adminDetails.getEmailId(), adminDetails.getAdminPassword()));
				SecurityContextHolder.getContext().setAuthentication(authentication);
				
				String jwt = jwtUtils.generateJwtToken(authentication);
				
				AdminDetailsImpl details = (AdminDetailsImpl) authentication.getPrincipal();
				if(details != null) {
					CustomeResponseForLogin response = new CustomeResponseForLogin(new Date(),"Login Successfull","200",jwt,fetchAdmin.getFirstName(),fetchAdmin.getLastName(),fetchAdmin.getEmailId());
					return new ResponseEntity<Object>(response,HttpStatus.OK);
				}else {
					CustomResponseForNoUser response = new CustomResponseForNoUser(new Date(),"Error in Authentication","409");
					return new ResponseEntity<Object>(response,HttpStatus.OK);
				}
				
			}else {
				CustomResponseForNoUser response = new CustomResponseForNoUser(new Date(),"Invalid Credentials","409");
				return new ResponseEntity<Object>(response,HttpStatus.OK);
			}
			
		}else {
			
			CustomResponseForNoUser response = new CustomResponseForNoUser(new Date(),"Admin Not Found..!!","409");
			return new ResponseEntity<Object>(response,HttpStatus.OK);
			
		}
		
	}
	
	

}
