package com.example.jwt.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.jwt.models.AdminDetails;
import com.example.jwt.repository.AdminRepository;
import com.example.jwt.service.AdminService;


@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	AdminRepository adminRepository;
	
	@Autowired
	PasswordEncoder encoder;
	
	@Override
	public AdminDetails createAdmin(AdminDetails adminDetails) {
		// TODO Auto-generated method stub
		
		adminDetails.setStatus("1");
		adminDetails.setAdminPassword(encoder.encode(adminDetails.getAdminPassword()));
		
		return adminRepository.save(adminDetails);
	}

	@Override
	public AdminDetails fetchAdminByEmail(String emailId) {
		// TODO Auto-generated method stub
		return adminRepository.fetchAdminByEmail(emailId);
	}

	
	
	

}
