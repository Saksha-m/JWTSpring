package com.example.jwt.service;

import com.example.jwt.models.AdminDetails;

public interface AdminService {

	AdminDetails createAdmin(AdminDetails adminDetails);

	AdminDetails fetchAdminByEmail(String emailId);

}
